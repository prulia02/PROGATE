// Tetapkan array yang diberikan sebagai constant animals
const animals = ["anjing", "kucing", "domba"];

// Print constant animals
console.log(animals);
