// Selesikan code loop for dibawah ini
for (let number = 1; number <= 100; number++) {
  // Gunakan statement if untuk mem-print string "Kelipatan 3" ketika angka yang diprint adalah angka kelipatan 3
  if (number % 3 === 0){
    console.log("Kelipatan 3");
  } else {
    console.log(number);
  }
}
