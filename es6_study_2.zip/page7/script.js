const animals = ["anjing", "kucing", "domba"];

// Gantikan element ketiga array menjadi "kelinci"
animals[2] = "kelinci";

// Print array ketiga dari constant animal ke console
console.log(animals[2]);
