// Tetapkan function ke constant hello
const hello = function(){
console.log("Halo!");
console.log("Saya Prulia");
};
// Panggil function yang ditetapkan di constant hello
hello();
