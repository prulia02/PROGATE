// Cetak "Hello World" ke console
console.log("Hello World");

// Cetak "Ninja Ken" ke console
console.log("Ninja Ken");

// Ubah baris dibawah menjadi komentar
console.log("Ubah baris ini menjadi komentar");
