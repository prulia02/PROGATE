let name = "Ninja Ken";
console.log(name);

// Update nilai variable ke "Birdie"
name="Birdie";
console.log(name);
// Cetak nilai dari variable name
console.log("Birdie");
