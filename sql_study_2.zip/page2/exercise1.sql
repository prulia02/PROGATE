/*
ambil data harga setelah pajak penjualan dari kolom price
dengan melanjutkan statement dibawah
*/

SELECT name, price, price * 1.09
FROM purchases;